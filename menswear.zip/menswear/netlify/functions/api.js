const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const defaultCategories = [
  { id: "shirts", name: "Shirts", image: "shirts.jpg", page: "shirts.html", enabled: true },
  { id: "tshirts", name: "T-Shirts", image: "tshirts.jpg", page: "tshirts.html", enabled: true },
  { id: "trousers", name: "Trousers", image: "trousers.jpg", page: "trousers.html", enabled: true },
  { id: "jackets", name: "Jackets", image: "jackets.jpg", page: "jackets.html", enabled: true },
  { id: "jeans", name: "Jeans", image: "jeans.jpg", page: "jeans.html", enabled: false },
  { id: "accessories", name: "Accessories", image: "accessories.jpg", page: "accessories.html", enabled: true }
];

const adminEmail = process.env.ADMIN_EMAIL || "admin@gmail.com";
const adminPassword = process.env.ADMIN_PASSWORD || "admin123";
const adminTokens = new Set();

function resolveDatabasePath() {
  const candidates = [
    path.resolve(__dirname, "../../data/db.json"),
    path.resolve(__dirname, "../../tmp/swatheesh/db.json"),
    "/tmp/swatheesh/db.json"
  ];

  const existing = candidates.find((filePath) => fs.existsSync(filePath));
  if (existing) return existing;

  const fallback = candidates[1] || candidates[2];
  fs.mkdirSync(path.dirname(fallback), { recursive: true });
  return fallback;
}

function ensureSeedDatabase() {
  const dbPath = resolveDatabasePath();
  if (fs.existsSync(dbPath)) return dbPath;

  const seed = {
    users: [],
    products: [],
    orders: [],
    categories: defaultCategories
  };

  fs.writeFileSync(dbPath, JSON.stringify(seed, null, 2) + "\n");
  return dbPath;
}

function readDatabase() {
  const dbPath = ensureSeedDatabase();
  return JSON.parse(fs.readFileSync(dbPath, "utf8"));
}

function writeDatabase(database) {
  const dbPath = resolveDatabasePath();
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  fs.writeFileSync(dbPath, `${JSON.stringify(database, null, 2)}\n`);
}

function jsonResponse(statusCode, payload) {
  return {
    statusCode,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  };
}

function parseBody(rawBody) {
  if (!rawBody) return {};
  try {
    return JSON.parse(rawBody);
  } catch {
    return {};
  }
}

function hashPassword(password) {
  return crypto.createHash("sha256").update(password).digest("hex");
}

exports.handler = async (event) => {
  const method = event.httpMethod || "GET";
  const rawPath = event.path || "/";
  const normalizedPath = rawPath.includes("/.netlify/functions/api")
    ? rawPath.replace("/.netlify/functions/api", "")
    : rawPath;
  const pathname = normalizedPath || "/";

  if (method === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
      },
      body: ""
    };
  }

  if (pathname === "/api/health" && method === "GET") {
    return jsonResponse(200, { ok: true, service: "swatheesh-menswear" });
  }

  if (pathname === "/api/admin/login" && method === "POST") {
    const body = parseBody(event.body);
    if (body.email !== adminEmail || body.password !== adminPassword) {
      return jsonResponse(401, { error: "Admin email or password is incorrect." });
    }

    const token = crypto.randomBytes(32).toString("hex");
    adminTokens.add(token);
    return jsonResponse(200, { token });
  }

  if (pathname === "/api/products" && method === "GET") {
    return jsonResponse(200, readDatabase().products || []);
  }

  if (pathname === "/api/categories" && method === "GET") {
    return jsonResponse(200, readDatabase().categories || defaultCategories);
  }

  if (pathname === "/api/orders" && method === "GET") {
    const token = (event.headers && event.headers.authorization ? event.headers.authorization : "").replace("Bearer ", "");
    if (!adminTokens.has(token)) {
      return jsonResponse(401, { error: "Admin login required." });
    }
    return jsonResponse(200, readDatabase().orders || []);
  }

  if (!["/api/users/register", "/api/users/login", "/api/orders", "/api/products", "/api/categories"].includes(pathname)) {
    return jsonResponse(404, { error: "Not found" });
  }

  const body = parseBody(event.body);
  const database = readDatabase();

  if (pathname === "/api/categories" && method === "PUT") {
    const token = (event.headers && event.headers.authorization ? event.headers.authorization : "").replace("Bearer ", "");
    if (!adminTokens.has(token)) {
      return jsonResponse(401, { error: "Admin login required." });
    }

    const categories = database.categories || defaultCategories;
    const categoryIndex = categories.findIndex((item) => item.id === body.id);
    if (categoryIndex < 0) {
      return jsonResponse(404, { error: "Category not found." });
    }

    categories[categoryIndex] = {
      ...categories[categoryIndex],
      name: String(body.name || "").trim(),
      image: String(body.image || "").trim(),
      page: String(body.page || "").trim(),
      enabled: Boolean(body.enabled)
    };
    database.categories = categories;
    writeDatabase(database);
    return jsonResponse(200, categories[categoryIndex]);
  }

  if (pathname === "/api/products" && ["POST", "PUT", "DELETE"].includes(method)) {
    const token = (event.headers && event.headers.authorization ? event.headers.authorization : "").replace("Bearer ", "");
    if (!adminTokens.has(token)) {
      return jsonResponse(401, { error: "Admin login required." });
    }
  }

  if (pathname === "/api/users/register" && method === "POST") {
    const email = String(body.email || "").trim().toLowerCase();
    if (!/^\S+@gmail\.com$/i.test(email) || String(body.password || "").length < 6) {
      return jsonResponse(400, { error: "Use a Gmail address and a password with at least 6 characters." });
    }

    if ((database.users || []).some((user) => user.email === email)) {
      return jsonResponse(409, { error: "An account with this email already exists." });
    }

    const user = {
      id: crypto.randomUUID(),
      name: String(body.name || "").trim(),
      email,
      passwordHash: hashPassword(body.password),
      createdAt: new Date().toISOString()
    };
    database.users.push(user);
    writeDatabase(database);
    return jsonResponse(201, { id: user.id, name: user.name, email: user.email });
  }

  if (pathname === "/api/users/login" && method === "POST") {
    const email = String(body.email || "").trim().toLowerCase();
    const user = (database.users || []).find((item) => item.email === email);
    if (!user || user.passwordHash !== hashPassword(String(body.password || ""))) {
      return jsonResponse(401, { error: "Email or password is incorrect." });
    }
    return jsonResponse(200, { id: user.id, name: user.name, email: user.email });
  }

  if (pathname === "/api/orders" && method === "POST") {
    if (!body.customer || !Array.isArray(body.items) || body.items.length === 0) {
      return jsonResponse(400, { error: "Customer details and order items are required." });
    }

    const order = {
      id: `SW-${Date.now().toString().slice(-6)}`,
      customer: body.customer,
      items: body.items,
      total: Number(body.total || 0),
      status: "pending",
      createdAt: new Date().toISOString()
    };

    database.orders.push(order);
    writeDatabase(database);
    return jsonResponse(201, order);
  }

  if (pathname === "/api/products" && method === "PUT") {
    const productIndex = (database.products || []).findIndex((item) => item.id === body.id);
    if (productIndex < 0) {
      return jsonResponse(404, { error: "Product not found." });
    }

    const product = {
      ...database.products[productIndex],
      name: String(body.name || "").trim(),
      category: String(body.category || "").trim().toLowerCase(),
      price: Number(body.price),
      stock: Number(body.stock),
      extraFields: Array.isArray(body.extraFields) ? body.extraFields : [],
      image: String(body.image || "").trim(),
      updatedAt: new Date().toISOString()
    };

    if (!product.name || !product.category || !Number.isFinite(product.price) || product.price < 0 || !Number.isInteger(product.stock) || product.stock < 0 || !product.image) {
      return jsonResponse(400, { error: "Name, category, valid price, stock, and image filename are required." });
    }

    database.products[productIndex] = product;
    writeDatabase(database);
    return jsonResponse(200, product);
  }

  if (pathname === "/api/products" && method === "DELETE") {
    const productId = body.id || (event.queryStringParameters && event.queryStringParameters.id);
    const productIndex = (database.products || []).findIndex((item) => item.id === productId);
    if (productIndex < 0) {
      return jsonResponse(404, { error: "Product not found." });
    }

    database.products.splice(productIndex, 1);
    writeDatabase(database);
    return jsonResponse(200, { ok: true });
  }

  if (pathname === "/api/products" && method === "POST") {
    const product = {
      id: crypto.randomUUID(),
      name: String(body.name || "").trim(),
      category: String(body.category || "").trim().toLowerCase(),
      price: Number(body.price),
      stock: Number(body.stock),
      extraFields: Array.isArray(body.extraFields) ? body.extraFields : [],
      image: String(body.image || "").trim(),
      createdAt: new Date().toISOString()
    };

    if (!product.name || !product.category || !Number.isFinite(product.price) || product.price < 0 || !Number.isInteger(product.stock) || product.stock < 0 || !product.image) {
      return jsonResponse(400, { error: "Name, category, valid price, stock, and image filename are required." });
    }

    database.products.push(product);
    writeDatabase(database);
    return jsonResponse(201, product);
  }

  return jsonResponse(405, { error: "Method not allowed." });
};
